//--------------------------------------------------------------------------------------
// AtgConsole.h
//
// Console class for simple applications that need no input and only console output.
// Use this INSTEAD of AtgApplication.
//
// Requires .TGA/.ABC files for the console font. 
//
// Xbox Advanced Technology Group.
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------
#pragma once
#ifndef ATGCONSOLE_H
#define ATGCONSOLE_H

#include <xtl.h>
#include "AtgDevice.h"
#include "AtgFont.h"

namespace ATG
{

//--------------------------------------------------------------------------------------
// Name: class Console
// Desc: Class to implement the console.
//--------------------------------------------------------------------------------------
class Console
{
public:
                    Console();
                    ~Console();

    // Initialization
    HRESULT         Create( LPCSTR strFontFileName,
                            D3DCOLOR colBackColor,
                            D3DCOLOR colTextColor,
                            UINT nLines = 0 );

    VOID            Destroy();

    // Added for the DLC fork's GameListUI, which needs the D3D device for its
    // own icon/progress-bar rendering but can't reach the private
    // m_pd3dDevice or the cross-module g_pd3dDevice global directly (the
    // fork tried referencing g_pd3dDevice from another compiland and hit a
    // linker issue pulling in its defining object file - reusing Console's
    // own already-reliably-linked device pointer avoids that entirely).
    static D3DDevice* GetDevice() { return m_pd3dDevice; }

    // Same reasoning as GetDevice above, for the present parameters.
    // XuiRenderInitShared() requires the D3DPRESENT_PARAMETERS the device was
    // actually created with, and m_d3dpp is private; reusing Console's copy
    // guarantees XUI is told the same back buffer format and size the device
    // really has rather than a reconstructed guess.
    static const D3DPRESENT_PARAMETERS* GetPresentParams() { return &m_d3dpp; }

    // Clear the screen
    VOID            Clear();

    // Console output
	virtual VOID    Display( LPCSTR strDisplay );
	virtual VOID    Display( LPCWSTR wstrDisplay );
    virtual VOID    Format( _In_z_ _Printf_format_string_ LPCSTR strFormat, ... );
    virtual VOID    Format( _In_z_ _Printf_format_string_ LPCWSTR wstrFormat, ... );
    virtual VOID    FormatV( _In_z_ _Printf_format_string_ LPCSTR strFormat, va_list pArgList );
    virtual VOID    FormatV( _In_z_ _Printf_format_string_ LPCWSTR wstrFormat, va_list pArgList );

    // Send output to debug channel
    VOID            SendOutputToDebugChannel( BOOL bOutputToDebugChannel )
    {
        m_bOutputToDebugChannel = bOutputToDebugChannel;
    }

    // method for rendering the console
    VOID            Render();

    // method for scrolling the text window up/down
    VOID            ScrollUp( INT nLines );

    static const INT PAGE_UP    = +255;
    static const INT PAGE_DOWN  = -255;

private:
    // Constants
    static const UINT SCREEN_SIZE_X_DEFAULT    = 640;
    static const UINT SCREEN_SIZE_Y_DEFAULT    = 480;
    static const UINT SCREEN_SIZE_X_720p       = 1280;
    static const UINT SCREEN_SIZE_Y_720p       = 720;
    static const UINT SCREEN_SIZE_X_1080p      = 1920;
    static const UINT SCREEN_SIZE_Y_1080p      = 1080;

    static const UINT SAFE_AREA_PCT_4x3        = 85;
    static const UINT SAFE_AREA_PCT_HDTV       = 90;

    // Safe area dimensions
    UINT m_cxSafeArea;
    UINT m_cySafeArea;

    UINT m_cxSafeAreaOffset;
    UINT m_cySafeAreaOffset;

    // Send console output to debug channel
    BOOL m_bOutputToDebugChannel;

    // Main objects used for creating and rendering the 3D scene
    static D3DPRESENT_PARAMETERS m_d3dpp;
    static D3DDevice* m_pd3dDevice;

    // Font for rendering text
    Font m_Font;

    // Colors
    D3DCOLOR m_colBackColor;
    D3DCOLOR m_colTextColor;

    // Text Buffers
    UINT m_cScreenHeight;        // height in lines of screen area
    UINT m_cScreenHeightVirtual; // height in lines of text storage buffer
    UINT m_cScreenWidth;         // width in characters
    FLOAT m_fLineHeight;          // height of a single line in pixels

    WCHAR* m_Buffer;               // buffer big enough to hold a full screen
    WCHAR** m_Lines;                // pointers to individual lines
    UINT m_nCurLine;             // index of current line being written to
    UINT m_cCurLineLength;       // length of the current line
    INT m_nScrollOffset;        // offset to display text (in lines)

    BOOL m_bSuspendFlag;         // Device suspended tracking flag

    // Add a character to the current line
    VOID            Add( CHAR ch );
    VOID            Add( WCHAR wch );

    // Increment to the next line
    VOID            IncrementLine();
};

}
// namespace ATG

#endif